package com.example.datamahasiswaapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    EditText etCari;
    Button btnCari;
    ProgressBar progressBar;
    TextView textError;

    List<Mahasiswa> mahasiswaList = new ArrayList<>();
    MahasiswaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerMahasiswa);
        etCari = findViewById(R.id.etCari);
        btnCari = findViewById(R.id.btnCari);
        progressBar = findViewById(R.id.progressBar);
        textError = findViewById(R.id.textError);
        etCari.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // 🔹 JIKA TEXT DIHAPUS → KEMBALI KE DATA AWAL
                if (s.length() == 0) {
                    loadLocalJson("");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });


        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MahasiswaAdapter(mahasiswaList);
        recyclerView.setAdapter(adapter);

        // 🔹 LOAD DATA SAAT APLIKASI DIBUKA
        loadLocalJson("");

        btnCari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String keyword = etCari.getText().toString();
                loadLocalJson(keyword);
            }
        });
    }

    // ===============================
    // LOAD JSON LOKAL (SESUAI UAS)
    // ===============================
    private void loadLocalJson(String keyword) {
        try {
            mahasiswaList.clear();
            progressBar.setVisibility(View.VISIBLE);
            textError.setVisibility(View.GONE);

            InputStream is = getAssets().open("mahasiswa.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();

            JSONArray array = new JSONArray(new String(buffer, "UTF-8"));

            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                String nama = obj.getString("nama");

                if (!keyword.isEmpty() &&
                        !nama.toLowerCase().contains(keyword.toLowerCase())) {
                    continue;
                }

                mahasiswaList.add(new Mahasiswa(
                        obj.getString("id"),
                        obj.getString("nama"),
                        obj.getString("nim"),
                        obj.getString("jurusan")
                ));
            }

            if (mahasiswaList.isEmpty()) {
                textError.setText("Data tidak ditemukan");
                textError.setVisibility(View.VISIBLE);
            }

            adapter.notifyDataSetChanged();
            progressBar.setVisibility(View.GONE);

        } catch (Exception e) {
            textError.setText("Terjadi kesalahan membaca data");
            textError.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
            e.printStackTrace();
        }
    }
}
